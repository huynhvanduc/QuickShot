using System.Drawing.Imaging;

namespace QuickShot;

/// <summary>
/// "Bộ não" của app. Sống suốt vòng đời process:
///  - hiện icon dưới tray
///  - đăng ký 2 hotkey
///  - giữ vùng đã chọn (_savedRegion) để chụp lại nhiều lần
/// </summary>
public sealed class TrayContext : ApplicationContext
{
    private readonly NotifyIcon _tray;
    private readonly HotkeyWindow _hotkeys;
    private Rectangle? _savedRegion;   // vùng đã "nhớ"; null = chưa định nghĩa

    // ==== ĐỔI HOTKEY TẠI ĐÂY nếu muốn ====
    private const Keys DefineKey = Keys.R;   // Ctrl+Alt+R : định nghĩa vùng
    private const Keys CaptureKey = Keys.S;  // Ctrl+Alt+S : chụp
    private const HotkeyWindow.Mod ModKeys = HotkeyWindow.Mod.Control | HotkeyWindow.Mod.Alt;

    public TrayContext()
    {
        _tray = new NotifyIcon
        {
            Icon = SystemIcons.Application,
            Visible = true,
            Text = "QuickShot — Ctrl+Alt+R định vùng | Ctrl+Alt+S chụp"
        };

        var menu = new ContextMenuStrip();
        menu.Items.Add("Định nghĩa vùng (Ctrl+Alt+R)", null, (_, _) => DefineRegion());
        menu.Items.Add("Chụp vùng (Ctrl+Alt+S)", null, (_, _) => CaptureRegion());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Thoát", null, (_, _) => ExitApp());
        _tray.ContextMenuStrip = menu;

        _hotkeys = new HotkeyWindow();
        bool ok1 = _hotkeys.Register(ModKeys, DefineKey, DefineRegion);
        bool ok2 = _hotkeys.Register(ModKeys, CaptureKey, CaptureRegion);

        if (!ok1 || !ok2)
            ShowBalloon("Cảnh báo",
                "Không đăng ký được hotkey (có thể bị app khác chiếm). Dùng menu chuột phải.");
    }

    // ---- Hotkey 1: kéo chọn & nhớ vùng ----
    private void DefineRegion()
    {
        using var selector = new RegionSelector();
        selector.ShowDialog();

        if (selector.Result is { } r)
        {
            _savedRegion = r;
            ShowBalloon("Đã nhớ vùng", $"{r.Width} x {r.Height}. Nhấn Ctrl+Alt+S để chụp.");
        }
    }

    // ---- Hotkey 2: chụp lại vùng đã nhớ ----
    private void CaptureRegion()
    {
        if (_savedRegion is not { } region)
        {
            ShowBalloon("Chưa có vùng", "Nhấn Ctrl+Alt+R để định nghĩa vùng trước.");
            return;
        }

        try
        {
            using var bmp = new Bitmap(region.Width, region.Height, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(bmp))
            {
                // Copy pixel từ màn hình vào bitmap
                g.CopyFromScreen(region.Location, Point.Empty, region.Size);
            }

            // 1) Copy clipboard (clone để bitmap không bị dispose mất)
            Clipboard.SetImage(new Bitmap(bmp));

            // 2) Lưu file vào %TEMP%
            string file = Path.Combine(
                Path.GetTempPath(),
                $"QuickShot_{DateTime.Now:yyyyMMdd_HHmmss_fff}.png");
            bmp.Save(file, ImageFormat.Png);

            ShowBalloon("Đã chụp", $"Clipboard + {file}");
        }
        catch (Exception ex)
        {
            ShowBalloon("Lỗi chụp", ex.Message);
        }
    }

    private void ShowBalloon(string title, string text)
    {
        _tray.BalloonTipTitle = title;
        _tray.BalloonTipText = text;
        _tray.ShowBalloonTip(2000);
    }

    private void ExitApp()
    {
        _tray.Visible = false;
        _tray.Dispose();
        _hotkeys.Dispose();
        ExitThread();
    }
}
